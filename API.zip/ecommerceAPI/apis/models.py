from django.db import models


class GeeksModel(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    price = models.IntegerField(default=0)
    
    def __str__(self):
        return self.title

class Products(models.Model):
    price = models.FloatField(default=0.00)
    material =  models.CharField(max_length=200)
    imgurl = models.CharField(max_length=200)
    madeat = models.CharField(max_length=200)
    
    def __str__(self):
        return self.title