# import viewsets
from rest_framework import viewsets

# import local data
from .serializers import GeeksSerializer, ProductSerializer
from .models import GeeksModel, Products

# create a viewset


class GeeksViewSet(viewsets.ModelViewSet):
	# define queryset
	queryset = GeeksModel.objects.all()

	# specify serializer to be used
	serializer_class = GeeksSerializer

class ProductSet(viewsets.ModelViewSet):
	# define queryset
	queryset = Products.objects.all()

	# specify serializer to be used
	serializer_class = ProductSerializer
